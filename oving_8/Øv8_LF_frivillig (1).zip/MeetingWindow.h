// MeetingWindow.h
#pragma once
#include "Window.h"
#include "GUI.h"
#include "Meeting.h"
#include "Person.h"
#include "Graph_lib.h"
using namespace Graph_lib;

// Meeting GUI, this implementation handles program state in the Window class
class MeetingWindow : public Graph_lib::Window {
public:
	static constexpr int btnW = 100; 
	static constexpr int btnH = 20;
	static constexpr int pad = 20;
	static constexpr int fieldPad = 60;
	static constexpr int fieldW = 230;
	static constexpr int fieldH = 15;

	MeetingWindow(Point xy, int w, int h, const string& title);

private:
	// Program data
	Vector_ref<Meeting> meetings;
	Vector_ref<Person> people;
	Vector_ref<Car> cars;
	Vector<Person*> leaders;

	Button quitBtn;

	// Meeting
	In_box meetingDay;
	In_box meetingStart;
	In_box meetingEnd;
	Choice meetingLocation;
	In_box meetingSubject;
	Choice meetingLeader;
	Button meetingNewBtn;

	// Add participant
	Choice meetingChoice;
	Choice personChoice;
	Button participantNewBtn;

	// Person
	In_box personName;
	In_box personEmail;
	In_box seats;
	Button personNewBtn;

	// Display
	Multiline_out_box data;

	Menu layoutMenu;

	void addMeeting();
	void addPerson();
	void addParticipant();
	void showMeetingPage();
	void showPersonPage();

	// Helper functions
	void displayMeetings();
	void displayPeople();

	static void cb_quit(Address, Address pw);
	static void cb_new_meeting(Address, Address pw);
	static void cb_new_person(Address, Address pw);
	static void cb_meetings(Address, Address pw);
	static void cb_persons(Address, Address pw);
	static void cb_new_participant(Address, Address pw);
};
