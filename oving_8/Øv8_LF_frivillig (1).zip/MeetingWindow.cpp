#include "MeetingWindow.h"

MeetingWindow::MeetingWindow(Point xy, int w, int h, const string& title)
	: Graph_lib::Window(xy, w, h, title),

	quitBtn{ Point{x_max() - btnW, 0}, btnW, btnH, "Quit", cb_quit },

	meetingSubject{ Point{fieldPad, pad}, fieldW, btnH, "Subject" },
	meetingDay{ Point{fieldPad, pad + btnH}, btnW / 2, btnH, "Day" },
	meetingStart{ Point{fieldPad + 1 * (btnW / 2 + 2 * pad), pad + btnH}, btnW / 2, btnH, "Start" },
	meetingEnd{ Point{fieldPad + 2 * (btnW / 2 + 2 * pad), pad + btnH}, btnW / 2, btnH, "End" },
	meetingLocation{ Point{fieldPad, pad + btnH * 2}, fieldW, btnH, "Location" },
	meetingLeader{ Point{fieldPad, pad + btnH * 3}, fieldW, btnH, "Leader" },
	meetingNewBtn{ Point{fieldPad, pad + btnH * 4}, btnW, btnH, "Add meeting", cb_new_meeting },
	data{ Point{pad, pad + btnH * 6 + pad}, x_max() - 2 * pad, y_max() - 3 * pad - btnH * 6 ,"" },

	personName{ Point{fieldPad, pad}, fieldW, btnH, "Name" },
	personEmail{ Point{fieldPad, pad + btnH}, fieldW, btnH, "Email" },
	seats{ Point{fieldPad, pad + btnH * 2}, fieldW, btnH, "Seats" },
	personNewBtn{ Point{fieldPad, pad + btnH * 3}, btnW, btnH, "Add person", cb_new_person },

	layoutMenu{ Point{x_max() - btnW, btnH * 2}, btnW, btnH, Menu::vertical, "Layout menu" },

	personChoice{ {fieldPad, pad + btnH * 5 + pad / 2}, btnW, btnH, "" },
	meetingChoice{ {fieldPad + 2 * btnW, pad + btnH * 5 + pad / 2}, btnW, btnH, "" },
	participantNewBtn{ {fieldPad + btnW , pad + btnH * 5 + pad / 2}, btnW, btnH, "add to" , cb_new_participant}
{
	// Common
	attach(quitBtn);

	// New meeting
	attach(meetingDay);
	attach(meetingStart);
	attach(meetingEnd);
	attach(meetingLocation);
	attach(meetingSubject);
	attach(meetingLeader);
	attach(meetingNewBtn);

	for (auto c : campusToString)
		meetingLocation.add(c.second);

	// New person
	attach(personName);
	attach(personEmail);
	attach(seats);
	attach(personNewBtn);

	// New participant
	attach(personChoice);
	attach(meetingChoice);
	attach(participantNewBtn);

	// Display
	attach(data);

	// Menu
	layoutMenu.attach(new Button{ Point{0, 0}, 0, 0, "Meetings", cb_meetings });
	layoutMenu.attach(new Button{ Point{0, 0}, 0, 0, "Persons", cb_persons });
	attach(layoutMenu);

	// Initial window
	showPersonPage();
}

void MeetingWindow::addMeeting()
{
	int day = meetingDay.get_int();
	int start = meetingStart.get_int();
	int end = meetingEnd.get_int();
	Campus campus = static_cast<Campus>(meetingLocation.value());
	const string& subject = meetingSubject.get_string();
	int leaderId = meetingLeader.value();

	if (day < 1 || 31 < day || start < 0 || 23 < start || end < start || subject.empty()
		|| leaderId < 0) {
		cerr << "Not enough information to add meeting.\n";
		return;
	}

	Person* leader = leaders[leaderId];
	meetings.push_back(new Meeting{ day, start, end, campus, subject, leader });

	meetingChoice.add(subject);

	displayMeetings();
}

void MeetingWindow::addPerson()
{

	const string& name = personName.get_string();
	const string& email = personEmail.get_string();
	if (name.empty() || email.empty()) {
		cerr << "Not enough information to add person.\n";
		return;
	}
	else
	{
		Car* car = nullptr;
		if (seats.get_int() > 0) {
			// Remove one to reserve driver's seat
			car = new Car{ seats.get_int() - 1 };
			cars.push_back(car);
		}

		people.push_back(new Person{ name, email, car });
		if (car)
		{
			meetingLeader.add(name);
			leaders.push_back(&people.back());
		}

		personChoice.add(name);
		displayPeople();
	}
}

void MeetingWindow::addParticipant()
{
	int meet = meetingChoice.value();
	int pers = personChoice.value();

	if (meet > -1 && pers > -1)
	{
		meetings[meet].addParticipant(&people[pers]);
		showMeetingPage();
	}
}

void MeetingWindow::showMeetingPage()
{
	meetingDay.show();
	meetingStart.show();
	meetingEnd.show();
	meetingLocation.show();
	meetingSubject.show();
	meetingLeader.show();
	meetingNewBtn.show();

	personChoice.show();
	meetingChoice.show();
	participantNewBtn.show();

	personName.hide();
	personEmail.hide();
	seats.hide();
	personNewBtn.hide();

	displayMeetings();
}

void MeetingWindow::showPersonPage()
{
	meetingDay.hide();
	meetingStart.hide();
	meetingEnd.hide();
	meetingLocation.hide();
	meetingSubject.hide();
	meetingLeader.hide();
	meetingNewBtn.hide();

	personChoice.hide();
	meetingChoice.hide();
	participantNewBtn.hide();

	personName.show();
	personEmail.show();
	seats.show();
	personNewBtn.show();

	displayPeople();
}

void MeetingWindow::displayMeetings()
{
	stringstream ss;
	for (auto m : meetings) {
		ss << *m << '\n';
	}
	data.put(ss.str());
}

void MeetingWindow::displayPeople()
{
	stringstream ss;
	for (auto p : people) {
		ss << *p << '\n';
	}
	data.put(ss.str());
}

// Callback functions
void MeetingWindow::cb_quit(Address, Address pw)
{
	reference_to<MeetingWindow>(pw).hide();
}
void MeetingWindow::cb_new_meeting(Address, Address pw)
{
	reference_to<MeetingWindow>(pw).addMeeting();
}
void MeetingWindow::cb_new_person(Address, Address pw)
{
	reference_to<MeetingWindow>(pw).addPerson();
}
void MeetingWindow::cb_meetings(Address, Address pw)
{
	reference_to<MeetingWindow>(pw).showMeetingPage();
}
void MeetingWindow::cb_persons(Address, Address pw)
{
	reference_to<MeetingWindow>(pw).showPersonPage();
}
void MeetingWindow::cb_new_participant(Address, Address pw)
{
	reference_to<MeetingWindow>(pw).addParticipant();
}
