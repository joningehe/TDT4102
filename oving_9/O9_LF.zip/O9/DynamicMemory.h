#pragma once

void createFibonacci();
