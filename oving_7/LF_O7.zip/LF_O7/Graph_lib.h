#ifndef WIN32

#pragma once
// Kode som utvider Graph_lib for øving 7

#include "Graph.h"

namespace Graph_lib {

class Arc : public Graph_lib::Shape
{
public:
	Arc(Point center, int w, int h, int sd, int ed)
		: w{w}, h{h}, start_deg{sd}, end_deg{ed}
	{
		add(Point{center.x - w / 2, center.y - h / 2});
	}

	void draw_lines() const override;

	void set_start(int d) { start_deg = d; }
	void set_end(int d) { end_deg = d; }
	void setw(int w) { this->w = w; }
	void seth(int h) { this->h = h; }

private:
	int w;
	int h;
	int start_deg;
	int end_deg;
};

} // namespace Graph_lib

#endif
