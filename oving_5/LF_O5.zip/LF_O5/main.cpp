#include "Blackjack.h"
#include "Card.h"

int main()
{
	// Seed random generator
	srand(static_cast<unsigned int>(time(nullptr)));

	// Validate that CardStruct behaves as expected
	CardStruct s10{Suit::spades, Rank::ten};
	CardStruct h14{Suit::hearts, Rank::ace};

	cout << toString(s10) << " [" << toStringShort(s10) << "]\n"
		 << toString(h14) << " [" << toStringShort(h14) << "]\n\n";

	// Play terminal version of blackjack
	blackjackTerminal();
}
