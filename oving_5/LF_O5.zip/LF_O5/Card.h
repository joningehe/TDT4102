#pragma once
#include "std_lib_facilities.h"

enum class Suit { clubs, diamonds, hearts, spades };
enum class Rank {
	two = 2,
	three,
	four,
	five,
	six,
	seven,
	eight,
	nine,
	ten,
	jack,
	queen,
	king,
	ace
};

const map<Suit, string> suitStrings {
	{Suit::clubs, "Clubs"},
	{Suit::diamonds, "Diamonds"},
	{Suit::hearts, "Hearts"},
	{Suit::spades, "Spades"}};

const map<Rank, string> rankStrings {
	{Rank::ace, "Ace"},
	{Rank::two, "Two"},
	{Rank::three, "Three"},
	{Rank::four, "Four"},
	{Rank::five, "Five"},
	{Rank::six, "Six"},
	{Rank::seven, "Seven"},
	{Rank::eight, "Eight"},
	{Rank::nine, "Nine"},
	{Rank::ten, "Ten"},
	{Rank::jack, "Jack"},
	{Rank::queen, "Queen"},
	{Rank::king, "King"}};

class Card
{
public:
	// Invartiant: s and r can only assume values defined by Suit and Rank enums
	Card();
	Card(Suit suit, Rank rank);

	Suit suit() const;
	Rank rank() const;
	string toString() const;
	string toStringShort() const;
	const bool isValid() const;
	// const _after_ the last parentheses in a member function
	// declaration means that the member function does not modify the
	// object. Violating this promise not to modify the object results
	// in a compilation error.

	// const _before_ the function name means that the object which is
	// returned can't be changed. Mostly useful for references.

private:
	Suit s;
	Rank r;
	bool valid;
};

// Oppgave 3i) Teori og refleksjon
// - Klasse: siden vi kan definere en meningsfull invariant for en kortstokk, så mener læreboken at
//   det er class som er det beste valget. Vi vet at et kort kun kan beskrives vha.
//   de fire fargene og de 13 forskjellige verdiene. Det _kan_ vi også gjøre vha. kun struct i dette
//   tilfellet. Det er siden enum-typene Suit og Rank ikke gjør det mulig å velge kort utenfor mengden
//   de typene representerer. Ifølge læreboken er det uansett god skikk å bruke klasser der det er
//   mulig å definere invarianter.
//   Se kapittel 9.3 og 9.4.3 i læreboken
//   Enda et element er at klassens private medlemmer ikke kan endres direkte fra utsiden. Det gjør
//   at endring av kortets tilstand fra utsiden begrenses til de medlemsfunksjonene/operasjonene som
//   defineres for klassen. Et kort bør f.eks. ikke ha mulighet til å endre sin farge eller verdi.
//   Det gjør det lettere å ivareta invarianten til klassen.
// - Invarianten til klassen er alle kort i en 52-korts kortstokk. Det betyr at vi med sikkerhet kan
//   si at alle mulige tilstander ethvert kort kan anta er en av 52 tilstander. 4 forskjellige farger
//   og 13 forskjellige verdier.


// Task 1 and 2
struct CardStruct
{
	Suit s;
	Rank r;
};

string rankToString(Rank r);
string suitToString(Suit s);
string toString(CardStruct cs);
string toStringShort(CardStruct cs);
