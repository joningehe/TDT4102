#include "Card.h"

Card::Card() : valid{false}
{}

// Invartiant: s and r constrained to Suit and Rank enums
Card::Card(Suit suit, Rank rank) : s{suit}, r{rank}, valid{true}
{}

Suit Card::suit() const
{
	return s;
}

Rank Card::rank() const
{
	return r;
}

const bool Card::isValid() const
{
	return valid;
}

string Card::toString() const
{
	if (valid)
		return rankToString(r) + " of " + suitToString(s);
	else
		return "Invalid card.";
}

string Card::toStringShort() const
{
	if (valid)
		return suitToString(s).at(0) + to_string(static_cast<int>(r));
	else
		return "Invalid Card.";
}



// Functions for the struct part of the exercise
string rankToString(Rank r)
{
	return rankStrings.at(r);
}

string suitToString(Suit s)
{
	return suitStrings.at(s);
}

string toString(CardStruct cs)
{
	return rankToString(cs.r) + " of " + suitToString(cs.s);
}

string toStringShort(CardStruct cs)
{
	return suitToString(cs.s).at(0) + to_string(static_cast<int>(cs.r));
}
