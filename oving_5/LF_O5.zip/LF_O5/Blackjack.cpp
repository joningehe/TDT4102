#include "Blackjack.h"

bool yn_question(string q)
// Ask question 'q' to console.
// Returns true when input from user is 'y', false otherwise
{
	char yn;
	cout << q << " (y/n) ";
	cin >> yn;
	cin.ignore(256, '\n'); // Multiple valid char inputs are ignored.

	return yn == 'y';

}

int BlackjackHand::sum() const
{
	int numAces = 0;
	int sum = 0;
	for (auto& c : cards) {
		// Count only valid cards, i.e. do not count the dealer's hidden card
		// until the player is done
		if (!c.isValid())
			continue;

		if (c.rank() != Rank::ace)
			sum += blackjackValues.at(c.rank());
		else
			++numAces;
	}

	if (sum > 10) // Will bust if aces are counted as 11
		sum += numAces;
	else if (numAces > 0)
		sum += blackjackValues.at(Rank::ace) + numAces - 1;

	return sum;
}


void Blackjack::reset()
{
	deck = CardDeck{};
	deck.shuffle();
	state = GameState::playing;
	dealerInit = true;
}

void Blackjack::drawInitial()
{
	player.cards.clear();
	dealer.cards.clear();

	playerDraw();
	dealerDraw();
	playerDraw();
	dealerDraw();
}

void Blackjack::roundInit()
{
	// Make sure that there are enough cards in the deck to complete a round
	if (deck.cardsLeft() < 16) // 1+1+1+1+2+2+2+2+3+3 and 3+3+4+4+4+4 (16 cards)
		reset();

	state = GameState::playing;
	dealerInit = true;

	drawInitial();

	int playerSum = player.sum();
	int dealerSum = dealer.sum() + BlackjackHand::blackjackValues.at(dealerHidden.rank());

	if (playerSum == scoreLimit && dealerSum == scoreLimit)
		endGame(GameState::draw);
	else if (playerSum == scoreLimit && dealerSum != scoreLimit)
		endGame(GameState::playerBlackjack);
	else if (playerSum != scoreLimit && dealerSum == scoreLimit)
		endGame(GameState::dealerBlackjack);
}

Card Blackjack::playerDraw()
{
	if (!playable())
		return Card{}; // Invalid card when round is lost/won/draw

	Card c = deck.drawCard();
	player.cards.push_back(c);

	if (player.sum() > scoreLimit)
		endGame(GameState::playerBust);

	return c;
}

void Blackjack::endGame(GameState s)
{
	state = s;
	dealer.cards[0] = dealerHidden; // Show hidden dealer card
}

void Blackjack::dealerDraw()
{
	Card c = deck.drawCard();

	if (!dealerInit) {
		dealer.cards.push_back(c);
	} else {
		dealer.cards.push_back(Card{}); // Invalid card (Hidden)
		dealerHidden = c;
		dealerInit = false;
	}
}

void Blackjack::playDealer()
{
	dealer.cards[0] = dealerHidden; // Show hidden dealer card
	if (!playable())
		return;

	while (dealer.sum() < dealerHitLimit)
		dealerDraw();

	int playerSum = player.sum();
	int dealerSum = dealer.sum();

	if (dealerSum > scoreLimit)
		endGame(GameState::dealerBust);
	else if (dealerSum < playerSum)
		endGame(GameState::playerWin);
	else if (dealerSum > playerSum)
		endGame(GameState::dealerWin);
	else
		endGame(GameState::draw);
}

const map<Rank, int> BlackjackHand::blackjackValues = {
	{Rank::ace, 11},  {Rank::two, 2},	{Rank::three, 3}, {Rank::four, 4}, {Rank::five, 5},
	{Rank::six, 6},   {Rank::seven, 7},  {Rank::eight, 8}, {Rank::nine, 9}, {Rank::ten, 10},
	{Rank::jack, 10}, {Rank::queen, 10}, {Rank::king, 10}};

void blackjackTerminal()
{
	Blackjack b;
	using GameState = Blackjack::GameState;

	b.reset();

	cout << "******** Blackjack TDT4102  ********\n";

	do {
		cout << "\n-=================+ New Round +=================-\n";

		b.roundInit();

		cout << "Dealer's hand:\n";
		for (auto& c : b.dealerHand().cards) {
			if (c.isValid())
				cout << c.toString() << '\n';
			else
				cout << "Hidden\n";
		}
		cout << "Totals: " << b.dealerHand().sum() << '\n';

		// player's turn to draw cards
		cout << "Your hand:\n";
		for (auto& c : b.playerHand().cards)
			cout << c.toString() << '\n';
		cout << "Totals: " << b.playerHand().sum() << '\n';

		while (b.playable() && yn_question("Do you want to draw another card?")) {
			Card c = b.playerDraw();
			cout << "You drew: " << c.toString() << '\n';
			cout << "Your hand totals: " << b.playerHand().sum() << '\n';
		}

		// dealer's turn to draw cards
		if (b.playable()) {
			cout << "Dealer is playing...\n";
			b.playDealer();
			cout << "Dealer's cards:\n";
			for (auto& c : b.dealerHand().cards)
				cout << c.toString() << '\n';
		}

		// dealer's done, do we have a winner?
		cout << "***************************\n";
		cout << "Your hand: " << b.playerHand().sum() << '\n';
		cout << "Dealer's hand: " << b.dealerHand().sum() << '\n';

		switch (b.gameState()) {
		case GameState::draw:
			cout << "It's a draw...\n";
			break;
		case GameState::playerBlackjack:
			cout << "Blackjack! Congratulations, you win!\n";
			break;
		case GameState::dealerBlackjack:
			cout << "Dealer blackjack! You lose.\n";
			break;
		case GameState::playerWin:
			cout << "You win!\n";
			break;
		case GameState::dealerWin:
			cout << "Dealer win!\n";
			break;
		case GameState::dealerBust:
			cout << "Dealer bust, you win!\n";
			break;
		case GameState::playerBust:
			cout << "You bust, dealer win!\n";
			break;
		default:;
		}
	} while (yn_question("Play again?"));
}
