#pragma once
#include "std_lib_facilities.h"
#include "Card.h"
#include "CardDeck.h"

// Yes/No question. Reads y as Yes, everything else as No.
bool yn_question(string q);

struct BlackjackHand
{
	vector<Card> cards;

	int sum() const;

	static const map<Rank, int> blackjackValues;
	// Static in a struct or class means that the variable is the same
	// one for every instance of the class. In this case, this means
	// that all BlackjackHand instances has exactly the same map named
	// blackjackValues.

	// Const means that this static variable can't be changed. It
	// prohibits changes to the map after instantiation of the map.
};

class Blackjack
{
public:
	enum GameState {
		playing,
		playerBlackjack,
		dealerBlackjack,
		draw,
		playerWin,
		dealerWin,
		playerBust,
		dealerBust
	};

	void playDealer();
	Card playerDraw();
	void roundInit();
	void reset();

	bool playable() const { return state == GameState::playing; }
	const GameState gameState() const { return state; }
	const BlackjackHand playerHand() const { return player; }
	const BlackjackHand dealerHand() const { return dealer; }

private:
	CardDeck deck;
	BlackjackHand player;
	BlackjackHand dealer;
	Card dealerHidden;
	bool dealerInit = true;
	GameState state;

	// constexpr members in classes has to be static. They have to be
	// static because they are evaluated at compile time.
	static constexpr int dealerHitLimit = 17;
	static constexpr int scoreLimit = 21;

	void drawInitial();
	void dealerDraw();
	void endGame(GameState s);
};

void blackjackTerminal();
