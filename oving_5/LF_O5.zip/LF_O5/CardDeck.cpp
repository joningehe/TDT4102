#include "CardDeck.h"

void CardDeck::print() const
{
	for (Card c : cards)
		cout << c.toString() << '\n';
}

void CardDeck::printShort() const
{
	for (Card c : cards)
		cout << c.toStringShort() << ' ';
	cout << '\n';
}

void CardDeck::shuffle()
{
	for (int i = 0; i < 52; ++i)
		swap(i, rand() % 52);
	currentCard = 0;
}

const Card& CardDeck::drawCard()
// Draw card from top of the deck.
{
	// This drawCard() version call the error() function when if the
	// deck is empty. It's not a part of the exercise to handle this
	// case, it's here to show a possible solution to empty decks.
	if (empty()) {
		error("There are no more cards in the deck.\n");
	}

	return cards[currentCard++];
	// ++ after the variable name: post-increment
	// What happens in this line?
	// 1. currentCard is incremented by 1.
	// 2. currentCard's previous value is returned from the increment operation. That is, the value before incrementing.
	// 3. cards is indexed at the position returned by the increment operation - the old value of currentCard.

	// Example:
	// - currentCard = 10 to begin with.
	// - calling currentCard++ produces the return value of currentCard before the function call, and increments the currentCard for future use.
	// - The value of currentCard is 11.
	// - The value used to lookup the vector cards is 10.
	// The book doesn't use this method, it's a classic source of e.g. counting errors and off-by-one errors.
	// You will, however, encounter this variant in a lot of code not in PPP.

	// If you use pre-increment, the resulting code might look like this:
	// int cardIndex = currentCard;
	// ++currentCard; // ++ før variabelnavn: pre-increment
	// return cards[cardIndex];
}

void CardDeck::swap(int i, int j)
{
	Card tmp = cards[i];
	cards[i] = cards[j];
	cards[j] = tmp;
}


// These methods are not a part of the exercise text, the methods are
// used to ease the implementation of blackjack in the solution guide.
bool CardDeck::empty() const
{
	return currentCard == cards.size();
}

int CardDeck::cardsLeft() const
{
	return 52 - currentCard;
}
