#pragma once
#include "Card.h"

class CardDeck
// French card deck with 52 cards. No jokers.
// Cards are drawn one at a time from the top of the deck.
{
public:
	CardDeck() : currentCard{0}
	{
		for (auto s : suitStrings) {
			for (auto r : rankStrings) {
				cards.push_back(Card{s.first, r.first});
			}
		}
	}

	void print() const;
	void printShort() const;
	void shuffle();
	const Card& drawCard();

	bool empty() const;
	int cardsLeft() const;

private:
	vector<Card> cards;
	int currentCard;
	void swap(int i, int j);
};
