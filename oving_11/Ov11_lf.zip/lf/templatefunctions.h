#pragma once

void testTemplateFunctions();
