#pragma once

void testStdLists();
