#pragma once

void iterators_vec();
void iterators_set();
