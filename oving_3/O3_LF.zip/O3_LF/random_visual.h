#include "Graph.h"
#include "Simple_window.h"

constexpr int win_x = 800;
constexpr int win_y = 600;
constexpr int margin = 30;
constexpr int axis_x_len = win_x - 2 * margin;
constexpr int axis_y_len = win_y - 2 * margin;
constexpr int origo_y = win_y - margin;
constexpr int step_size = 10;
constexpr int rand_points = 1000;
constexpr int x_axis_n_marks = axis_x_len / step_size;

const Color annuity_color = Color::dark_blue;
const Color series_color = Color::dark_red;

// Using vector<unique_ptr<>> and automatic heap memory management.
unique_ptr<Marks> bar_y(const int n,
						const Point origin,
						const string mark = "*");
// Precondition: n = number of occurrences/height
// Precondition: origin = starting position of bar
// Postcondition: unique_ptr<Marks> to a bar of marks starting at origin of
// height h, drawn "upwards"

vector<unique_ptr<Marks>> histogram(const vector<int>& values,
									const Point origin,
									const string mark = "*",
									int step_sz = step_size);
// Precondition: values = y values ordered on x, ascending
// Precontidion: origin = starting position of histogram
// Postcondition: vector<unique_ptr<Marks>> to a histogram of bars
// starting at origin of height h, drawn "upwards"

// Draw a histogram and add wait-for button, for this exercise in the
// interval [0, 73]
void fltkHistogram(Simple_window& window, vector<int> values, const string name);
