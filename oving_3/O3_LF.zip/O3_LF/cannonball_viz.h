#pragma once

void cannonBallViz(double targetPosition,
				   int fieldLength,
				   double velocityX,
				   double velocityY,
				   int timeSteps);
