#include "random_visual.h"

unique_ptr<Marks> bar_y(const int n,
						const Point origin,
						const string mark)
{
	constexpr int mark_height = 10;
	unique_ptr<Marks> bar = make_unique<Marks>(mark);
	for (int i = 0; i < n; ++i)
		bar->add({ origin.x, origin.y - i * mark_height });

	return bar;
}

vector<unique_ptr<Marks>> histogram(const vector<int>& values,
									const Point origin,
									const string mark,
									int step_sz)
{
	vector<unique_ptr<Marks>> hist;
	int x = origin.x;
	for (auto it = values.begin(); it < values.end(); ++it, x += step_sz)
		hist.push_back(bar_y(*it, { x, origin.y }, mark));

	return hist;
}

void fltkHistogram(Simple_window& window, vector<int> values, const string name)
{
	Axis x{ Axis::x, { margin, origo_y }, axis_x_len, 2, "x" };
	Axis y{ Axis::y, { margin, origo_y }, axis_y_len, 2, "y" };
	x.set_color(Color::black);
	y.set_color(Color::black);
	window.attach(x);
	window.attach(y);
	window.set_label(name);

	auto histo = histogram(values,
                           { margin + 5, win_y - margin },
                           "*",
                           step_size);
	for (auto&& b : histo)
		window.attach(*b);

	window.wait_for_button();

	for (auto&& b : histo)
		window.detach(*b);
}
