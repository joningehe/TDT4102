#pragma once
#include "utilities.h"

void testCallByValue();
void testCallByReference();
void testVectorSorting();
void testString();
