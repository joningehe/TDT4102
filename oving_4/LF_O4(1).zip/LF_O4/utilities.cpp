#include "utilities.h"

int incrementByValueNumTimes(int startValue, int increment, int numTimes)
{
	for (int i = 0; i < numTimes; i++)
		startValue += increment;

	return startValue;
}

void incrementByValueNumTimesRef(int& startValue, int increment, int numTimes)
{
	for (int i = 0; i < numTimes; i++)
		startValue += increment;
}

void swapNumbers(int& a, int& b)
{
	int tmp = a;
	a = b;
	b = tmp;
}

void randomizeVector(vector<int>& vec, int n)
{
	for (int i = 0; i < n; ++i)
		vec.push_back(rand() % 100);
}

void sortVector(vector<int>& vec)
{
	// Insertion sort, implementation from wikipedia pseudocode
	for (int i = 1; i < vec.size(); ++i) {
		for (int j = i; 0 < j && vec[j - 1] > vec[j]; --j) {
			swapNumbers(vec[j], vec[j - 1]);
		}
	}
}

double medianOfVector(const vector<int>& vec)
// Precondition: vec is sorted.
// Postcondition: even n: mean value of the two elements in the middle, odd n: middle element.
{
	if (vec.size() % 2 == 0) {
		// Even number of elements in vector
		int m = static_cast<int>(vec.size() / 2 - 1);
		int n = static_cast<int>(vec.size() / 2);
		return static_cast<double>((vec[m] + vec[n]) / 2.0);
	}

	return static_cast<double>(vec[static_cast<int>(vec.size() / 2)]);
}

string randomizeString(int n, char lower, char upper)
{
	string str;
	for (int i = 0; i < n; ++i)
		str += lower + (rand() % (upper - lower));

	return str;
}

string readInputToString(int n, char lower, char upper)
{
	string str;
	// The variable ch is introduced in the scope of the for-loop. In general, a smaller (more local scope) is better, when possible.
	// For every iteration, check that n is not equal to 0 (more characters to read), and read the character into ch 
	for (char ch; str.size() < n && cin >> ch; ) {
		// skip characters that are not alphanumric
		if (isalnum(ch)) {
			ch = toupper(ch); // change to uppercase
			if (lower <= ch && ch <= upper) {
				str += ch;
			}
		}
	}

	// discard overflowing input on same line
	cin.clear();
	cin.ignore(255, '\n');

	return str;
}

int countChar(string str, char ch)
{
	int n = 0;
	for (char c : str) {
		if (c == ch) {
			++n;
		}
	}

	return n;

	// STL algorithm
	// return count(str.begin(), str.end(), ch);
}
