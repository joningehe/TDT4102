#include "utilities.h"
#include "mastermind.h"
#include "masterVisual.h"
#include <cassert> // For assert()

bool yn_question(string q)
// Returns true when input from user is 'y', false otherwise
{
	char yn;
	cout << q << " (y/n) ";
	cin >> yn;
	cin.ignore(256, '\n'); // Multiple valid char inputs are ignored.
	if (yn == 'y')
		return true;
	return false;
	// return yn == 'y';
}

void playMastermind()
{
	constexpr int size = 4;
	constexpr int letters = 6;
	constexpr char startLetter = 'A';
	constexpr int maxTries = 6;

	// Graphic part constants
	constexpr int win_w = 400; // try 200, it shows that the scaling works only to some extent, not very good
	constexpr int win_h = 600;

	bool playAgain = false;
	do {
		string code = randomizeString(size, startLetter, startLetter + letters - 1);
		string guess;
		int round = 0;
		cout << "*** Mastermind ***\n";

		// Grafikk
		MastermindWindow mwin{Point{900, 20}, win_w, win_h, "Mastermind"};

		cout << "Colors: a = red, b = green, c = yellow, d = blue, e = lilac, f = cyan\n\n";
		// show the CODE. addGuess is used to show the code with parameter round = 0
		addGuess(mwin, code, size, startLetter, round);
		// win.wait_for_button(); // For debug, show secret code
		hideCode(mwin, size);
		mwin.wait_for_button();

		// cout << "Code (debug): " << code << '\n';
		while (guess != code && round != maxTries) {
			cout << "What's your guess? (" << size << " chars) ";
			guess = readInputToString(size, startLetter, startLetter + letters - 1);
			++round;

			int correct = checkCharactersAndPosition(code, guess);
			int correctChars = checkCharacters(code, guess);

			// Grafikk
			addGuess(mwin, guess, size, startLetter, round);
			addFeedback(mwin, correct, correctChars, size, round);
			mwin.wait_for_button();

			if (correct == size) {
				break;
			}

			cout << "Correct characters: " << correctChars
				 << "\nCorrect positions: " << correct << "\nYou have " << maxTries - round
				 << " tries left.\n";
		}

		if (guess == code) {
			cout << "Congratulations, you cracked the code!\n";
		} else {
			cout << "You didn't manage to crack the code...\n";
		}

		playAgain = yn_question("Do you want to play again?");
	} while (playAgain);
}

int checkCharactersAndPosition(string code, string guess)
// precondition: code.length() >= guess.length()
// Here we use the comment above to explicitly state the precondition,
// and we use assert() to check the pre-condition. In general it is
// NOT recommended to have comments that says exactly the same as what you
// can read from code, so the comment is debateable
{
	assert(code.length() >= guess.length());
	int count = 0;
	for (unsigned int i = 0; i < code.length(); ++i) {
		if (code[i] == guess[i]) {
			++count;
		}
	}
	return count;
}

int checkCharacters(string code, string guess)
// precondition: code.length() >= guess.length()
{
	assert(code.length() >= guess.length());
	set<char> guessSet;
	for (char ch : guess) {
		guessSet.insert(ch);
	}

	int count = 0;
	for (char ch : guessSet) {
		int guessCount = countChar(guess, ch);
		int codeCount = countChar(code, ch);
		count += min(guessCount, codeCount);
	}

	return count;
}
