#include "std_lib_facilities.h"
#include "tests.h"
#include "mastermind.h"

void skip_to_int();

int main()
{
	srand(static_cast<unsigned int>(time(nullptr))); // Seed the random generation engine

	constexpr int quit = 9;
	int choice = 0;
	while (choice != quit) {
		cout << "Test menu:\n"
				"1: call by value versus call by reference\n"
				"2: test vector sorting\n"
				"3: test strings\n"
				"4: play mastermind\n"
			 << quit << ": Quit\n> ";

		// Read only ints
		while (!(cin >> choice)) // Page 360-362, avoids runtime problems
			skip_to_int();		 // if anything else than int is input

		switch (choice) {
		case 1:
			cout << "Call by value:\n";
			testCallByValue();
			cout << "Call by reference:\n";
			testCallByReference();
			break;
		case 2:
			cout << "Randomize and sort vector:\n";
			testVectorSorting();
			break;
		case 3:
			cout << "String tests:\n";
			testString();
			break;
		case 4:
			playMastermind();
			break;
		case quit:
			cout << "Avslutter\n";
			exit(0);
		default:
			cout << "Ugyldig valg, prøv igjen.\n";
		}

		cout << '\n';
	}
}

void skip_to_int()
{
	// (not required for passing this exercise)
	// function is called when reading an int did not succeed
	if (cin.fail()) {				// do we have an error on cin?
		cin.clear();				// skip error, continue reading
		for (char ch; cin >> ch;) { // ch is as local as possible, smaller scope gives in general
									// better code, when possible.
			if (isdigit(ch)) {
				cin.unget(); // digit found, OK
				return;
			}
		}
	}
}
