#pragma once
#include "std_lib_facilities.h"

void writeUserInputToFile();
void addLineNumbers(string filename);
void characterStatistics(string filename);
