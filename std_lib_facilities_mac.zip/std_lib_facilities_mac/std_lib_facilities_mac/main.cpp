#include "std_lib_facilities.h"

int main(){
    
    // Your code here
    
    return 0;
}
