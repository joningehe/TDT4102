#include "std_lib_facilities.h" // vector (Vector)
#include "Graph.h"
#include "Simple_window.h"

void drawPlot(vector<int> annuity, vector<int> series, int loan, int rate);
